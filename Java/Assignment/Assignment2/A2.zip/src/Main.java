
public class Main {
	public static void main(String[] args) {
		// 21827263 Murat Celik
		String personnel = args[0];
		String monitoring = args[1];
		// firstly, I read two document
		ControlCheck.readInput(personnel, monitoring);

	}
}
