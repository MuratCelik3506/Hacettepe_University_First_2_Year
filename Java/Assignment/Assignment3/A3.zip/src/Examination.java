
public abstract class Examination extends Patient {
	Patient examination;
	// for additional operation

	
	}

