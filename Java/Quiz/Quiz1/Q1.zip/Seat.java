public class Seat {
    Integer seatID;
    Boolean status;
    String Passenger;

    static void seat(Integer seatID, Boolean status, String Passenger){

    }
}
