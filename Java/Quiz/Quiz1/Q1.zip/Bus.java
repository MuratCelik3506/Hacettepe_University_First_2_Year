public class Bus {
    static void bookSeat(Passenger p, int seatID) {
    }

    static void printAllPaasengers() {
    }

    static void printAllAvailableSeatIDs() {
    }

    static void search() {
    }
}
