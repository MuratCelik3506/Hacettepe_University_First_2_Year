public class Phone {
    Integer Countrycode ;
    Integer Code ;
    Integer Number ;
    String Type;

    static void phone(Integer Countrycode, Integer Code, Integer Number, String Type){


    }
    static void phone ( Integer Code, Integer Number, String Type) {


    }
}
