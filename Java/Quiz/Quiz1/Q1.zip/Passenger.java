public class Passenger {
    String Name  ;
    String Surname ;
    String Gender ;
    Integer Phone ;

    static void passenger ( String Name, String Surname, String Gender, Integer Phone){



    }
}
